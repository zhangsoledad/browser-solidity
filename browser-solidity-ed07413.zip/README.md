# Automatic build
Built website from `ed07413`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `browser-solidity-ed07413.zip`.
